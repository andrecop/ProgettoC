#include <stdio.h>
#include <stdlib.h>
#include "bmp.h"
#include "ip_lib.h"
#include <sys/stat.h>
#include <sys/types.h>
#include <string.h>

/*
1) bm_load(char *input);
2) bm_free(Bitmap *pointer);
3) bitmap_to_ip_mat(Bitmap *pointer)
4) clamp(ip_mat *pointer,0,255)
5) ip_mat_to_bitmap(ip_mat *pointer);
6) bm_save(Bitmap *pointer,char *nomeFileOutput);*/


int main(void)
{
    Bitmap   *foto1;
    Bitmap   *foto2;
    Bitmap   *output;
    char     nomeInput1[100];
    char     nomeInput2[100];
    char     Input1[100];
    char     Input2[100];
    char     nomeFolder[100];
    char     folder[100] = "./";
    char     slash[] = "/";
    char     formato[] = ".bmp";
    char     foto[200];
    ip_mat   *struttura1;
    ip_mat   *struttura2;
    ip_mat   *risultante;
    ip_mat   *esempio;
/*
    ip_mat   *esempio2;
    ip_mat   *esempio3;
*/
    //float val;

    printf("\nNome cartella dove salvare le foto: ");
    scanf("%s",nomeFolder);
    strcat(folder, nomeFolder);
    mkdir(folder,0777);
    printf("\n");
    printf("--Inserire i nomi senza formato--\n");
    printf("Nome foto 1: ");
    scanf("%s",nomeInput1);
    printf("Nome foto 2: ");
    scanf("%s",nomeInput2);
    printf("\n");

    strcat(folder, slash);

    strcat(Input1, folder);
    strcat(nomeInput1, formato);
    strcat(Input1, nomeInput1);

    strcat(Input2, folder);
    strcat(nomeInput2, formato);
    strcat(Input2, nomeInput2);

    foto1 = bm_load(nomeInput1);
    foto2 = bm_load(nomeInput2);

    struttura1 = bitmap_to_ip_mat(foto1);
    struttura2 = bitmap_to_ip_mat(foto2);

    printf("ip_mat_to_gray_scale ");
    risultante = ip_mat_to_gray_scale(struttura1);
    clamp(risultante,0,255);
    output = ip_mat_to_bitmap(risultante);
    memset(foto, 0, sizeof foto);
    strcat(foto, folder);
    strcat(foto, "ip_mat_to_gray_scale");
    strcat(foto, formato);
    bm_save(output,foto);
    bm_free(output);
    ip_mat_free(risultante);
    printf("OK\n");

    printf("ip_mat_blend ");
    risultante = ip_mat_blend(struttura1, struttura2, 50);
    clamp(risultante,0,255);
    output = ip_mat_to_bitmap(risultante);
    memset(foto, 0, sizeof foto);
    strcat(foto, folder);
    strcat(foto, "ip_mat_blend");
    strcat(foto, formato);
    bm_save(output,foto);
    bm_free(output);
    ip_mat_free(risultante);
    printf("OK\n");

    printf("ip_mat_brighten ");
    risultante = ip_mat_brighten(struttura1, 2);
    clamp(risultante,0,255);
    output = ip_mat_to_bitmap(risultante);
    memset(foto, 0, sizeof foto);
    strcat(foto, folder);
    strcat(foto, "ip_mat_brighten");
    strcat(foto, formato);
    bm_save(output,foto);
    bm_free(output);
    ip_mat_free(risultante);
    printf("OK\n");

    printf("ip_mat_corrupt ");
    risultante = ip_mat_corrupt(struttura1, 50);
    clamp(risultante,0,255);
    output = ip_mat_to_bitmap(risultante);
    memset(foto, 0, sizeof foto);
    strcat(foto, folder);
    strcat(foto, "ip_mat_corrupt");
    strcat(foto, formato);
    bm_save(output,foto);
    bm_free(output);
    ip_mat_free(risultante);
    printf("OK\n");

    printf("sharpen_filter ");
    esempio = create_sharpen_filter();
    risultante = ip_mat_convolve(struttura1, esempio);
    clamp(risultante,0,255);
    output = ip_mat_to_bitmap(risultante);
    memset(foto, 0, sizeof foto);
    strcat(foto, folder);
    strcat(foto, "sharpen_filter");
    strcat(foto, formato);
    bm_save(output,foto);
    bm_free(output);
    ip_mat_free(esempio);
    ip_mat_free(risultante);
    printf("OK\n");

    printf("edge_filter ");
    esempio = create_edge_filter();
    risultante = ip_mat_convolve(struttura1, esempio);
    clamp(risultante,0,255);
    output = ip_mat_to_bitmap(risultante);
    memset(foto, 0, sizeof foto);
    strcat(foto, folder);
    strcat(foto, "edge_filter");
    strcat(foto, formato);
    bm_save(output,foto);
    bm_free(output);
    ip_mat_free(esempio);
    ip_mat_free(risultante);
    printf("OK\n");

    printf("emboss_filter ");
    esempio = create_emboss_filter();
    risultante = ip_mat_convolve(struttura1, esempio);
    clamp(risultante,0,255);
    output = ip_mat_to_bitmap(risultante);
    memset(foto, 0, sizeof foto);
    strcat(foto, folder);
    strcat(foto, "emboss_filter");
    strcat(foto, formato);
    bm_save(output,foto);
    bm_free(output);
    ip_mat_free(esempio);
    ip_mat_free(risultante);
    printf("OK\n");

    printf("average_filter ");
    esempio = create_average_filter(3,3,3);
    risultante = ip_mat_convolve(struttura1, esempio);
    clamp(risultante,0,255);
    output = ip_mat_to_bitmap(risultante);
    memset(foto, 0, sizeof foto);
    strcat(foto, folder);
    strcat(foto, "average_filter");
    strcat(foto, formato);
    bm_save(output,foto);
    bm_free(output);
    ip_mat_free(esempio);
    ip_mat_free(risultante);
    printf("OK\n");

    printf("gaussian_filter ");
    esempio = create_gaussian_filter(3,3,3,1.2);
    risultante = ip_mat_convolve(struttura1, esempio);
    clamp(risultante,0,255);
    output = ip_mat_to_bitmap(risultante);
    memset(foto, 0, sizeof foto);
    strcat(foto, folder);
    strcat(foto, "gaussian_filter");
    strcat(foto, formato);
    bm_save(output,foto);
    bm_free(output);
    ip_mat_free(esempio);
    ip_mat_free(risultante);
    printf("OK\n");

/*
    esempio = ip_mat_create(10, 20, 3, 1.54);
    printf("Matrice 1 (ip_mat_create):\n");
    ip_mat_show(esempio);
    ip_mat_show_stats(esempio);

    printf("\nget_val: %f\n", get_val(esempio, 1,1,1));

    printf("Inserire il valore da settare:");
    scanf("%f", &val);
    set_val(esempio, 1,1,1,val);
    printf("\n%f\n", get_val(esempio, 1,1,1));
    printf("Matrice 1 (set_val):\n");
    ip_mat_show(esempio);
    ip_mat_show_stats(esempio);

    ip_mat_init_random(esempio, 10, 1);
    printf("Matrice 1 (ip_mat_init_random):\n");
    ip_mat_show(esempio);
    ip_mat_show_stats(esempio);

    esempio2 = ip_mat_copy(esempio);
    printf("Matrice 2 (ip_mat_copy):\n");
    ip_mat_show(esempio2);
    ip_mat_show_stats(esempio2);

    ip_mat_subset(esempio2, 1, 7, 5, 15);
    printf("Matrice 2 (ip_mat_subset):\n");
    ip_mat_show(esempio2);
    ip_mat_show_stats(esempio2);

    esempio2 = ip_mat_create(10, 20, 3, 1.54);
    esempio3 = ip_mat_concat(esempio, esempio2, 0);
    printf("Matrice 3 - concat su dim 0:\n");
    ip_mat_show(esempio3);
    ip_mat_show_stats(esempio3);

    esempio3 = ip_mat_concat(esempio, esempio2, 1);
    printf("Matrice 3 - concat su dim 1:\n");
    ip_mat_show(esempio3);
    ip_mat_show_stats(esempio3);

    esempio3 = ip_mat_concat(esempio, esempio2, 2);
    printf("Matrice 3 - concat su dim 2:\n");
    ip_mat_show(esempio3);
    ip_mat_show_stats(esempio3);

    esempio3 = ip_mat_sum(esempio, esempio2);
    printf("Matrice 3 (ip_mat_sum):\n");
    ip_mat_show(esempio3);
    ip_mat_show_stats(esempio3);

    esempio3 = ip_mat_sub(esempio, esempio2);
    printf("Matrice 3 (ip_mat_sub):\n");
    ip_mat_show(esempio3);
    ip_mat_show_stats(esempio3);

    esempio2 = ip_mat_mul_scalar(esempio2, 2);
    printf("Matrice 2 (ip_mat_mul_scalar 2):\n");
    ip_mat_show(esempio2);
    ip_mat_show_stats(esempio2);

    esempio2 = ip_mat_add_scalar(esempio2, 2);
    printf("Matrice 2 (ip_mat_add_scalar 2):\n");
    ip_mat_show(esempio2);
    ip_mat_show_stats(esempio2);

    esempio3 = ip_mat_mean(esempio, esempio2);
    printf("Matrice 3 (ip_mat_mean):\n");
    ip_mat_show(esempio3);
    ip_mat_show_stats(esempio3);
*/


    printf("\nPulizia finale ip_mat ");
    ip_mat_free(struttura1);
    ip_mat_free(struttura2);
    //ip_mat_free(esempio2);
    //ip_mat_free(esempio3);
    bm_free(foto1);
    bm_free(foto2);
    printf("OK\n\n");
    

    return 0;
    
}
